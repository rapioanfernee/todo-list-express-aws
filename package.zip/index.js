import express from "express";
import dotenv from "dotenv";
import serverless from "serverless-http";

import { prepareTable } from "./dynamodb.config.js";

dotenv.config();

const app = express();
const port = 3000;

app.use(express.json());

app.get("/tasks", (req, res) => {
  res.send("Test Tasks");
});

app.get("/tasks/:id", (req, res) => {
  res.send(`Test Tasks ${req.params.id}`);
});

if (process.env.DEVELOPMENT) {
  prepareTable();
  app.listen(port, () => {
    console.log("Server is running on port: ", port);
  });
}

const handleRequest = serverless(app);

export const handler = async (event, context) => {
  return await handleRequest(event, context);
};
